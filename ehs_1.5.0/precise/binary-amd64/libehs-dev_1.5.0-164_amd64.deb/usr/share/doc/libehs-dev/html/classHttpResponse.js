var classHttpResponse =
[
    [ "HttpResponse", "classHttpResponse.html#a8fb2fa6b1dfe32bb655a425049165349", null ],
    [ "~HttpResponse", "classHttpResponse.html#a87982136f19aade6fd46dea316af94c0", null ],
    [ "Error", "classHttpResponse.html#a2d61cbb29f5ae9b17fa63d0f0611cbe4", null ],
    [ "Error", "classHttpResponse.html#a8f99ffcd539e7ecfbbd02ba7f700a743", null ],
    [ "GetCookies", "classHttpResponse.html#a1f420725169b024f052540a7a602e4ca", null ],
    [ "GetHeaders", "classHttpResponse.html#a649854b947cb5da797e8052c3cb17bc6", null ],
    [ "GetPhrase", "classHttpResponse.html#a245f7d2774f4d3399127c28fb65fa27e", null ],
    [ "GetResponseCode", "classHttpResponse.html#a18ae8cda7994ce4ea3efc70e61196604", null ],
    [ "GetStatusString", "classHttpResponse.html#aadf0a211cb6377a81313d63b507b3ea6", null ],
    [ "Header", "classHttpResponse.html#a2a1312a4df18596270a80d8474bda8c4", null ],
    [ "HttpTime", "classHttpResponse.html#a94cfb8423ff79876dc283e8d0106bba1", null ],
    [ "RemoveHeader", "classHttpResponse.html#a06ae0fda48b2445a2a60aa6a5622a89c", null ],
    [ "SetBody", "classHttpResponse.html#a38f06d36c0ba8a0f0f5c122e35af9f85", null ],
    [ "SetCookie", "classHttpResponse.html#a88429c09c07f522fbd353180d480750e", null ],
    [ "SetDate", "classHttpResponse.html#a33e12174db7961ff594bde5be2c30203", null ],
    [ "SetHeader", "classHttpResponse.html#a815dcd389b03b68bcd09add90c81bc95", null ],
    [ "SetLastModified", "classHttpResponse.html#a717482781b2bcfdb33a13e783ba8a534", null ],
    [ "SetResponseCode", "classHttpResponse.html#a16774c4dcd1b47cf3c8152854b0ac84c", null ]
];