var searchData=
[
  ['sdatum',['sDatum',['../classDatum.html#aeab205a62362aa53081f4d01422e1561',1,'Datum']]]
];
