var searchData=
[
  ['_5f_5fcaseless',['__caseless',['../struct____caseless.html',1,'']]]
];
