var files =
[
    [ "config.h", null, null ],
    [ "contentdisposition.h", null, null ],
    [ "datum.h", null, null ],
    [ "debug.h", null, null ],
    [ "ehs.h", null, null ],
    [ "ehsconnection.h", null, null ],
    [ "ehsserver.h", null, null ],
    [ "ehstypes.h", null, null ],
    [ "formvalue.h", null, null ],
    [ "httprequest.h", null, null ],
    [ "httpresponse.h", null, null ],
    [ "networkabstraction.h", null, null ],
    [ "securesocket.h", null, null ],
    [ "socket.h", null, null ],
    [ "samples/base64.h", null, null ],
    [ "samples/sha1.h", null, null ],
    [ "samples/wscommon.h", null, null ],
    [ "samples/wsendpoint.h", null, null ],
    [ "samples/wsframe.h", null, null ],
    [ "samples/wsutf8.h", null, null ]
];