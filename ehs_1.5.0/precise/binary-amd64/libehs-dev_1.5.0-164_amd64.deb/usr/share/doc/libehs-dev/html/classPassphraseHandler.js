var classPassphraseHandler =
[
    [ "~PassphraseHandler", "classPassphraseHandler.html#a7bc538c21704d95da92be684b09e1f79", null ],
    [ "GetPassphrase", "classPassphraseHandler.html#a8bcae0bbc0de66876fd0be90e65869ff", null ]
];