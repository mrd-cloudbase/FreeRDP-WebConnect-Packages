var struct____caseless =
[
    [ "operator()", "struct____caseless.html#a1b99620a5fa56393bea986999e03b394", null ]
];