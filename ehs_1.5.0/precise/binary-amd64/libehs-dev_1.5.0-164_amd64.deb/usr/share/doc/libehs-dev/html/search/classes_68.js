var searchData=
[
  ['httprequest',['HttpRequest',['../classHttpRequest.html',1,'']]],
  ['httpresponse',['HttpResponse',['../classHttpResponse.html',1,'']]]
];
