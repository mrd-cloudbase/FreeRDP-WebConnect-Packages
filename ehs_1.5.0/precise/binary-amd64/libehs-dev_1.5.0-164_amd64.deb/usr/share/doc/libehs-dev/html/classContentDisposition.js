var classContentDisposition =
[
    [ "ContentDisposition", "classContentDisposition.html#a905bfc2e8ffb9baa319c8abe7e8a041c", null ],
    [ "~ContentDisposition", "classContentDisposition.html#a224029ed74bbdba73ede66ea67ecb123", null ],
    [ "m_oContentDispositionHeaders", "classContentDisposition.html#aba4876ce6f432c03f9ebfbd612874290", null ],
    [ "m_sContentDisposition", "classContentDisposition.html#a91ec2ae46652ced7b1c9f954bc1156f7", null ]
];