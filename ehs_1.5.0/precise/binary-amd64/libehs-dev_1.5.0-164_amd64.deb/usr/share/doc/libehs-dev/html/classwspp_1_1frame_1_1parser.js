var classwspp_1_1frame_1_1parser =
[
    [ "parser", "classwspp_1_1frame_1_1parser.html#acfa110eeedccd30a91c067a4a5647ae2", null ],
    [ "consume", "classwspp_1_1frame_1_1parser.html#a988f135e1d53f8c46fc106bc045b09ff", null ],
    [ "get_close_code", "classwspp_1_1frame_1_1parser.html#a3ba9f3e4774f70cc455f3bcf170ffae6", null ],
    [ "get_close_reason", "classwspp_1_1frame_1_1parser.html#aa0a07ff88fd3034b05ef666784f0931c", null ],
    [ "get_header_str", "classwspp_1_1frame_1_1parser.html#a9da42af1a99d0bf1ab3d2005f954bdd2", null ],
    [ "get_opcode", "classwspp_1_1frame_1_1parser.html#a31eaa19a3743bee523f6cfcbb396f20b", null ],
    [ "get_payload", "classwspp_1_1frame_1_1parser.html#a5fb18b6b3deebd0543118d6d3a0ae75d", null ],
    [ "get_payload_str", "classwspp_1_1frame_1_1parser.html#a590e3e7a2ad9ddc952e8ad545ad59ba7", null ],
    [ "is_control", "classwspp_1_1frame_1_1parser.html#a4fbf96dcc415eaf622ec6f7e84ef7887", null ],
    [ "ready", "classwspp_1_1frame_1_1parser.html#a9fb588fd953e06ac889fc2789a5d3467", null ],
    [ "reset", "classwspp_1_1frame_1_1parser.html#ad20897c5c8bd47f5d4005989bead0e55", null ],
    [ "set_fin", "classwspp_1_1frame_1_1parser.html#a9b64903944872cba35ca3dc5583f87a1", null ],
    [ "set_masked", "classwspp_1_1frame_1_1parser.html#a1fbfbbba48327179e8441efdaa2fb2d9", null ],
    [ "set_opcode", "classwspp_1_1frame_1_1parser.html#a6aa8cfe5dba50c9df10aad61813f2281", null ],
    [ "set_payload", "classwspp_1_1frame_1_1parser.html#a5a4f1748667aae244e9a00adadac7dc5", null ],
    [ "set_payload", "classwspp_1_1frame_1_1parser.html#ab1daab4a853fd15d517bff7f4722db4b", null ]
];