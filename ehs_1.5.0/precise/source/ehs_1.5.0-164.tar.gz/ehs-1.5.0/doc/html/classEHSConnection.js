var classEHSConnection =
[
    [ "AddResponse", "classEHSConnection.html#a6799c4968d9d894c2cf5ad2ae23640cf", null ],
    [ "Disconnected", "classEHSConnection.html#a511a9d39996a48527315e323ce785f72", null ],
    [ "EnableIdleTimeout", "classEHSConnection.html#a49094d32f71717f2d95ee84325252e76", null ],
    [ "EnableKeepAlive", "classEHSConnection.html#a9f278f5b5e5f05d1ce03e95ed81d9e6a", null ],
    [ "GetAddress", "classEHSConnection.html#ad227f0c9a122e35064c41b3d17bc3551", null ],
    [ "GetLocalAddress", "classEHSConnection.html#aaf8cd703a163f7b8e89237fbb429fd71", null ],
    [ "GetLocalPort", "classEHSConnection.html#ab0eb9c19c69b2f51a732e36dde6fe8f9", null ],
    [ "GetPort", "classEHSConnection.html#a75f62c0ae4ac36e5fb697d36cfb6d3ae", null ],
    [ "GetRemoteAddress", "classEHSConnection.html#a83e3c60496e3c40fa0ac5317bfde30dc", null ],
    [ "GetRemotePort", "classEHSConnection.html#a1a2affea3520e3a810077ad83b010e8c", null ],
    [ "IsRaw", "classEHSConnection.html#a870aabdc78c676a035e5529f762f59de", null ],
    [ "EHSServer", "classEHSConnection.html#a5bbe64ae04081d07b114a8df976c7d83", null ]
];