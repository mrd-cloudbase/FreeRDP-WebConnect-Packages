var classtracing_1_1wserror =
[
    [ "wserror", "classtracing_1_1wserror.html#ab58205d39b1fde720f5e741595485ef9", null ],
    [ "~wserror", "classtracing_1_1wserror.html#ab1cf222fc2eab6f6bf06a46e85428429", null ],
    [ "code", "classtracing_1_1wserror.html#af20e842bc6ee0c1ea1f9d67fa8ddcd44", null ],
    [ "what", "classtracing_1_1wserror.html#aff06f49065b54a8a86e02e9a2441a8ba", null ]
];