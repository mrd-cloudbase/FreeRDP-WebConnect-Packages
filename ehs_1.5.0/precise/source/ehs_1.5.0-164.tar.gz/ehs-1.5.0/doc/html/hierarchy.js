var hierarchy =
[
    [ "__caseless", "struct____caseless.html", null ],
    [ "ContentDisposition", "classContentDisposition.html", null ],
    [ "Datum", "classDatum.html", null ],
    [ "EHSConnection", "classEHSConnection.html", null ],
    [ "EHSServer", "classEHSServer.html", null ],
    [ "FormValue", "classFormValue.html", null ],
    [ "GenericResponse", "classGenericResponse.html", [
      [ "HttpResponse", "classHttpResponse.html", null ]
    ] ],
    [ "HttpRequest", "classHttpRequest.html", null ],
    [ "MutexHelper", "classMutexHelper.html", null ],
    [ "NetworkAbstraction", "classNetworkAbstraction.html", [
      [ "Socket", "classSocket.html", null ]
    ] ],
    [ "parser< rng_policy >", "classwspp_1_1frame_1_1parser.html", null ],
    [ "PassphraseHandler", "classPassphraseHandler.html", [
      [ "EHS", "classEHS.html", null ]
    ] ],
    [ "PrivilegedBindHelper", "classPrivilegedBindHelper.html", null ],
    [ "RawSocketHandler", "classRawSocketHandler.html", null ],
    [ "SHA1", "classSHA1.html", null ],
    [ "simple_rng", "classwspp_1_1simple__rng.html", null ],
    [ "validator", "classutf8__validator_1_1validator.html", null ],
    [ "wsendpoint", "classwspp_1_1wsendpoint.html", null ],
    [ "wserror", "classtracing_1_1wserror.html", null ],
    [ "wshandler", "classwspp_1_1wshandler.html", null ]
];