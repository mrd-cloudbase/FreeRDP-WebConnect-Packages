var classGenericResponse =
[
    [ "GenericResponse", "classGenericResponse.html#a033229b98353c8f64ccb05673563c711", null ],
    [ "~GenericResponse", "classGenericResponse.html#afbf71ebe4f40f920b0cb1ee6ee0012e6", null ],
    [ "EnableIdleTimeout", "classGenericResponse.html#a49094d32f71717f2d95ee84325252e76", null ],
    [ "EnableKeepAlive", "classGenericResponse.html#a9f278f5b5e5f05d1ce03e95ed81d9e6a", null ],
    [ "GetBody", "classGenericResponse.html#ad37d78372a46e3c5a61b5f00f17b9297", null ],
    [ "GetConnection", "classGenericResponse.html#adad15161af1596e68d521197b51fc954", null ],
    [ "SetBody", "classGenericResponse.html#a38f06d36c0ba8a0f0f5c122e35af9f85", null ],
    [ "EHSConnection", "classGenericResponse.html#a6277984745b90ae19ca685159e769c13", null ],
    [ "EHSServer", "classGenericResponse.html#a5bbe64ae04081d07b114a8df976c7d83", null ],
    [ "m_nResponseId", "classGenericResponse.html#a3c4af926889b6329432a7de421c32614", null ],
    [ "m_poEHSConnection", "classGenericResponse.html#a85f797b1620c470dd7e2ee463699aaf6", null ],
    [ "m_sBody", "classGenericResponse.html#a541643c029e4f376d3aa489bad3ad3d6", null ]
];