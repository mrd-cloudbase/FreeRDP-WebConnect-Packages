var classNetworkAbstraction =
[
    [ "~NetworkAbstraction", "classNetworkAbstraction.html#a3ec3edead9d4512657ee92a0b86b9227", null ],
    [ "Accept", "classNetworkAbstraction.html#a92db63796e7fbb1eda6f4feb4ed1bf0c", null ],
    [ "Close", "classNetworkAbstraction.html#aacb6d0e5e6d570cdc2b0da14c3921ff0", null ],
    [ "GetAddress", "classNetworkAbstraction.html#af361dea92c1531b39daf10c545aea444", null ],
    [ "GetFd", "classNetworkAbstraction.html#afbd8346761bcff95608f7699acf6cb78", null ],
    [ "GetLocalAddress", "classNetworkAbstraction.html#a971ac1f2b964614d7951a1f1791b3274", null ],
    [ "GetLocalPort", "classNetworkAbstraction.html#ac91e72b760001406a0d652d7d39c0244", null ],
    [ "GetPeer", "classNetworkAbstraction.html#a389a5b788151fb84bee0841fd0302bfe", null ],
    [ "GetPort", "classNetworkAbstraction.html#a8e027c3e7b32284537c2b72432bc5269", null ],
    [ "GetRemoteAddress", "classNetworkAbstraction.html#ac93a324e1b8d1894db5f6e6f59cea51f", null ],
    [ "GetRemotePort", "classNetworkAbstraction.html#ab7c1d2fa153b4b3226536b7b51183331", null ],
    [ "Init", "classNetworkAbstraction.html#aa3be9b7bb8732c812d0b1a4419f4c71d", null ],
    [ "IsSecure", "classNetworkAbstraction.html#af51837a62c20311e975a8221f7154618", null ],
    [ "Read", "classNetworkAbstraction.html#ac528bc6c32f4fe2da2dec3fd69fff834", null ],
    [ "RegisterBindHelper", "classNetworkAbstraction.html#aba62c74bc8b337a7a7f9fdff88cce2ad", null ],
    [ "Send", "classNetworkAbstraction.html#a4c48be522bbefb0163e314fbf4905b6a", null ],
    [ "SetBindAddress", "classNetworkAbstraction.html#a300d6c9ec49a1c04b3be59d78d2ae98f", null ],
    [ "ThreadCleanup", "classNetworkAbstraction.html#a0f10f071959a41e6d226bf814dfd9abf", null ]
];