var classwspp_1_1wshandler =
[
    [ "wshandler", "classwspp_1_1wshandler.html#ad357307aa9e84a975cae71e7a3aebf0a", null ],
    [ "~wshandler", "classwspp_1_1wshandler.html#a10d5c105a64ffea5698bb378f8e9ed73", null ],
    [ "send_binary", "classwspp_1_1wshandler.html#a738357a5c23ea5e62c07ef3efffdff89", null ],
    [ "send_text", "classwspp_1_1wshandler.html#adabd35f3f1aa2070965cb86fb2ada502", null ],
    [ "wsendpoint", "classwspp_1_1wshandler.html#a9ca8c0866431799c0ad8af686cf36c25", null ]
];