var classtracing_1_1logic__error =
[
    [ "logic_error", "classtracing_1_1logic__error.html#aa1eda4d3002d58937b6afd617f928c3c", null ],
    [ "~logic_error", "classtracing_1_1logic__error.html#a56101bb108e37563b34ff0a09608a957", null ],
    [ "what", "classtracing_1_1logic__error.html#aa7b4966fdd1b649f5abcdacfbfe6b5b9", null ]
];