var classtracing_1_1runtime__error =
[
    [ "runtime_error", "classtracing_1_1runtime__error.html#a4dd34fcb81cbc66663cece926d87af61", null ],
    [ "~runtime_error", "classtracing_1_1runtime__error.html#ab19da8b759156058c3e2067b92a10c55", null ],
    [ "what", "classtracing_1_1runtime__error.html#a8563a1b1ac72bb2f32f80e68d31e5353", null ]
];