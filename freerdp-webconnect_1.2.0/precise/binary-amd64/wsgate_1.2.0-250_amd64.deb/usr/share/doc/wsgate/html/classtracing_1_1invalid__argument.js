var classtracing_1_1invalid__argument =
[
    [ "invalid_argument", "classtracing_1_1invalid__argument.html#a55c12dfce5983abe574cccdcec181e08", null ]
];