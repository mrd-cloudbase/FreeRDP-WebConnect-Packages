var searchData=
[
  ['ntservice',['NTService',['../classwsgate_1_1NTService.html#ad818d7bed53b99ab4196a72f2fecabc9',1,'wsgate::NTService']]]
];
