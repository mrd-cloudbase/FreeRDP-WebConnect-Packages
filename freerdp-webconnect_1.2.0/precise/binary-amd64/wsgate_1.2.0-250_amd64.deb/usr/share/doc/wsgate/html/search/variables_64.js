var searchData=
[
  ['debug',['debug',['../classwsgate_1_1logger.html#a682fbe4a570b9395ee7c47e225d81de0',1,'wsgate::logger']]]
];
