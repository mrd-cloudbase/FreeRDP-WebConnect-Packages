var searchData=
[
  ['alert',['alert',['../classwsgate_1_1logger.html#a98b8cff4af9cf5e8b954f2c655d16912',1,'wsgate::logger']]]
];
