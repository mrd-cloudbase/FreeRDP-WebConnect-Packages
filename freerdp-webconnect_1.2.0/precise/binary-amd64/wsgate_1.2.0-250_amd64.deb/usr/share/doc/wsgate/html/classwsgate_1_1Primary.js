var classwsgate_1_1Primary =
[
    [ "Primary", "classwsgate_1_1Primary.html#a825085c695f5a3880ef8137f9c2b6ffb", null ],
    [ "~Primary", "classwsgate_1_1Primary.html#a8e6ed5435efd6ad04f04ff8a731f63fd", null ],
    [ "Register", "classwsgate_1_1Primary.html#a508fd565a08d9f42c46c9402324c8717", null ]
];