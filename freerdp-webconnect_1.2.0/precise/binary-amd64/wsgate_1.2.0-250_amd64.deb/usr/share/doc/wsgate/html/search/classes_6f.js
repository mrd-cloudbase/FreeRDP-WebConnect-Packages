var searchData=
[
  ['out_5fof_5frange',['out_of_range',['../classtracing_1_1out__of__range.html',1,'tracing']]],
  ['overflow_5ferror',['overflow_error',['../classtracing_1_1overflow__error.html',1,'tracing']]]
];
