var classwsgate_1_1RDP =
[
    [ "cursor", "classwsgate_1_1RDP.html#a557093f468a2b2c61e2037028aa15f1a", null ],
    [ "CursorMap", "classwsgate_1_1RDP.html#a59755d3fff6f70eb0b92b8cd996d1a4b", null ],
    [ "State", "classwsgate_1_1RDP.html#a4e779b2ca991fc818f21ae9c3d5c7c51", null ],
    [ "RDP", "classwsgate_1_1RDP.html#a9d32fba9cad35bfedaeaed5796facb2b", null ],
    [ "~RDP", "classwsgate_1_1RDP.html#aa89964a54f5983607843502b315edcdb", null ],
    [ "CheckFileDescriptor", "classwsgate_1_1RDP.html#a8745b59c44a73d91d3c24b8f115e21b3", null ],
    [ "Connect", "classwsgate_1_1RDP.html#a3e77cbc520126b4a503d90df457edc72", null ],
    [ "Disconnect", "classwsgate_1_1RDP.html#aa3bff98adaa80524a5eaf23f4a616787", null ],
    [ "GetCursor", "classwsgate_1_1RDP.html#a23c05638b329a0dc5fff1dd4437f0052", null ],
    [ "OnWsMessage", "classwsgate_1_1RDP.html#a13d26aa8a8269f3e350a825290791ad8", null ],
    [ "SetError", "classwsgate_1_1RDP.html#a0fbbecc019f7b5d3f63d7e8750a9cca5", null ]
];