var searchData=
[
  ['serverrunningstatus',['ServerRunningStatus',['http://ehs.fritz-elfert.de/html/classEHSServer.html#a5831b2149e05e9a3fc46fca5002c54fd',1,'EHSServer']]],
  ['state',['State',['../classwsgate_1_1RDP.html#a4e779b2ca991fc818f21ae9c3d5c7c51',1,'wsgate::RDP']]]
];
