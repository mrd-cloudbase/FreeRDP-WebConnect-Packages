var searchData=
[
  ['emerg',['emerg',['../classwsgate_1_1logger.html#a19a183e4bf22af61b82f01580c4e72a9',1,'wsgate::logger']]],
  ['err',['err',['../classwsgate_1_1logger.html#ad731a4369a94e34667b07e0f383956a9',1,'wsgate::logger']]]
];
