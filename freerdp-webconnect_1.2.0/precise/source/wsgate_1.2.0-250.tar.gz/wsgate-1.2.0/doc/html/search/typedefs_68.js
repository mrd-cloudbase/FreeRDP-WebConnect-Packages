var searchData=
[
  ['handler_5fptr',['handler_ptr',['../namespacewsgate.html#affc9f8544d59abe73c2b0dd7eeeb91c3',1,'wsgate']]]
];
