var classtracing_1_1dummy__tracer =
[
    [ "dummy_tracer", "classtracing_1_1dummy__tracer.html#a59a2cbd8a89b539dcedf4bc58b175416", null ],
    [ "trace", "classtracing_1_1dummy__tracer.html#a77b3426a4c5395b7fd06e68f28606241", null ]
];