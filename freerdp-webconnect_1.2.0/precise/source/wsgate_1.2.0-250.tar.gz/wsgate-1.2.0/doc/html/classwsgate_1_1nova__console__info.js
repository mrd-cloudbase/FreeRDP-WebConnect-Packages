var classwsgate_1_1nova__console__info =
[
    [ "nova_console_info", "classwsgate_1_1nova__console__info.html#a85cf19f6c65bd12d7222dbcf44a3c262", null ],
    [ "host", "classwsgate_1_1nova__console__info.html#aaa38013b3e0f060be5ed351bc543ec8e", null ],
    [ "internal_access_path", "classwsgate_1_1nova__console__info.html#a24212962a36ea7e631a5bc57314ef8cf", null ],
    [ "port", "classwsgate_1_1nova__console__info.html#aa6b3401e4310eace898d5ae845a5f17a", null ]
];