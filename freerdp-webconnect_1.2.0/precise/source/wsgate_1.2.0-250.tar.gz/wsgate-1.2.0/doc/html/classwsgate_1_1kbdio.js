var classwsgate_1_1kbdio =
[
    [ "kbdio", "classwsgate_1_1kbdio.html#a31c61ec17397cbf137b3afce29dd1d6e", null ],
    [ "~kbdio", "classwsgate_1_1kbdio.html#aa27c4a98ddd38bfc4d1a390ec6728153", null ],
    [ "qpressed", "classwsgate_1_1kbdio.html#a29de376a87fa686b05e86d23a82c1f51", null ]
];