var classtracing_1_1exception =
[
    [ "exception", "classtracing_1_1exception.html#a762984f7947d717b8f54eb87a592c065", null ],
    [ "~exception", "classtracing_1_1exception.html#ae4ffe36b00f103637950d5ef346cfc5f", null ],
    [ "where", "classtracing_1_1exception.html#a497e92eb2826dfd9ff1c3929463b6791", null ]
];