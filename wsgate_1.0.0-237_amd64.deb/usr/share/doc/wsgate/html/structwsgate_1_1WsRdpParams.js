var structwsgate_1_1WsRdpParams =
[
    [ "fntlm", "structwsgate_1_1WsRdpParams.html#a51141727756c13812dc3c5b01814f6ce", null ],
    [ "height", "structwsgate_1_1WsRdpParams.html#a855789843e66861be9926b17a65fb78b", null ],
    [ "nomani", "structwsgate_1_1WsRdpParams.html#aa2cbaf6a6c876eaca88b5de94f12447f", null ],
    [ "nonla", "structwsgate_1_1WsRdpParams.html#ad575202e9ed0fe279342468c7a1d4bdb", null ],
    [ "notheme", "structwsgate_1_1WsRdpParams.html#a29caf121ac37f983c4c8f02c619c8aa2", null ],
    [ "notls", "structwsgate_1_1WsRdpParams.html#a5ff3668890cd164ebbe108ea891a0168", null ],
    [ "nowallp", "structwsgate_1_1WsRdpParams.html#a7d4e0ef6502c2ea457182130016d169c", null ],
    [ "nowdrag", "structwsgate_1_1WsRdpParams.html#a65a4316a0cd6f8e17a5a15f948ef0b42", null ],
    [ "perf", "structwsgate_1_1WsRdpParams.html#ae37cbea70bb594dbf5805a062844461b", null ],
    [ "port", "structwsgate_1_1WsRdpParams.html#a8dd77cede716115cd407c82d08168459", null ],
    [ "width", "structwsgate_1_1WsRdpParams.html#acc8e802f468c7dfb4556c7159afb87ee", null ]
];