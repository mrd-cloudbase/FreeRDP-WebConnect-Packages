var namespacetracing =
[
    [ "wserror", "http://ehs.fritz-elfert.de/html/classtracing_1_1wserror.html", null ],
    [ "dummy_tracer", "classtracing_1_1dummy__tracer.html", null ],
    [ "bfd_tracer", "classtracing_1_1bfd__tracer.html", null ],
    [ "dwarf_tracer", "classtracing_1_1dwarf__tracer.html", null ],
    [ "exception", "classtracing_1_1exception.html", null ],
    [ "runtime_error", "classtracing_1_1runtime__error.html", null ],
    [ "logic_error", "classtracing_1_1logic__error.html", null ],
    [ "domain_error", "classtracing_1_1domain__error.html", null ],
    [ "invalid_argument", "classtracing_1_1invalid__argument.html", null ],
    [ "length_error", "classtracing_1_1length__error.html", null ],
    [ "out_of_range", "classtracing_1_1out__of__range.html", null ],
    [ "range_error", "classtracing_1_1range__error.html", null ],
    [ "overflow_error", "classtracing_1_1overflow__error.html", null ],
    [ "underflow_error", "classtracing_1_1underflow__error.html", null ]
];