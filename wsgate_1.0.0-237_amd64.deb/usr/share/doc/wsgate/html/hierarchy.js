var hierarchy =
[
    [ "tracing::bfd_tracer", "classtracing_1_1bfd__tracer.html", null ],
    [ "tracing::dummy_tracer", "classtracing_1_1dummy__tracer.html", null ],
    [ "tracing::dwarf_tracer", "classtracing_1_1dwarf__tracer.html", null ],
    [ "tracing::exception", "classtracing_1_1exception.html", [
      [ "tracing::logic_error", "classtracing_1_1logic__error.html", [
        [ "tracing::domain_error", "classtracing_1_1domain__error.html", null ],
        [ "tracing::invalid_argument", "classtracing_1_1invalid__argument.html", null ],
        [ "tracing::length_error", "classtracing_1_1length__error.html", null ],
        [ "tracing::out_of_range", "classtracing_1_1out__of__range.html", null ]
      ] ],
      [ "tracing::runtime_error", "classtracing_1_1runtime__error.html", [
        [ "tracing::overflow_error", "classtracing_1_1overflow__error.html", null ],
        [ "tracing::range_error", "classtracing_1_1range__error.html", null ],
        [ "tracing::underflow_error", "classtracing_1_1underflow__error.html", null ]
      ] ]
    ] ],
    [ "wsgate::http_exception", "classwsgate_1_1http__exception.html", null ],
    [ "wsgate::kbdio", "classwsgate_1_1kbdio.html", null ],
    [ "wsgate::logger", "classwsgate_1_1logger.html", null ],
    [ "wsgate::nova_console_info", "classwsgate_1_1nova__console__info.html", null ],
    [ "wsgate::nova_console_token_auth", "classwsgate_1_1nova__console__token__auth.html", null ],
    [ "wsgate::nova_console_token_auth_factory", "classwsgate_1_1nova__console__token__auth__factory.html", null ],
    [ "wsgate::NTService", "classwsgate_1_1NTService.html", null ],
    [ "wsgate::Png", "classwsgate_1_1Png.html", null ],
    [ "wsgate::Primary", "classwsgate_1_1Primary.html", null ],
    [ "RawSocketHandler", "http://ehs.fritz-elfert.de/html/classRawSocketHandler.html", [
      [ "wsgate::MyRawSocketHandler", "classwsgate_1_1MyRawSocketHandler.html", null ]
    ] ],
    [ "wsgate::RDP", "classwsgate_1_1RDP.html", null ],
    [ "wsgate::Update", "classwsgate_1_1Update.html", null ],
    [ "wsgate::wsgContext", "structwsgate_1_1wsgContext.html", null ],
    [ "wsgate::WsRdpParams", "structwsgate_1_1WsRdpParams.html", null ]
];