var structwsgate_1_1wsgContext =
[
    [ "_p", "structwsgate_1_1wsgContext.html#a7692deaf6498ce56ebcea1aac4009f27", null ],
    [ "clrconv", "structwsgate_1_1wsgContext.html#af500c19a73f07d21b30a5cd00db90304", null ],
    [ "pPrimary", "structwsgate_1_1wsgContext.html#a4349978aa47427a6e401be1d607f66bd", null ],
    [ "pRDP", "structwsgate_1_1wsgContext.html#a03abdae92c2163a262889a1fcca49c4d", null ],
    [ "pUpdate", "structwsgate_1_1wsgContext.html#a51119478548910b171be3299eea908b2", null ]
];