var classwsgate_1_1Update =
[
    [ "Update", "classwsgate_1_1Update.html#aa3ce84807824f70d3562bfc6918f5e49", null ],
    [ "~Update", "classwsgate_1_1Update.html#a48264583647f9a6c62d1d156c02f45cf", null ],
    [ "Register", "classwsgate_1_1Update.html#aba5c433ef2f3510da0009e4cbd30fcba", null ]
];