var namespacewspp =
[
    [ "wshandler", "http://ehs.fritz-elfert.de/html/classwspp_1_1wshandler.html", null ],
    [ "wsendpoint", "http://ehs.fritz-elfert.de/html/classwspp_1_1wsendpoint.html", null ],
    [ "simple_rng", "http://ehs.fritz-elfert.de/html/classwspp_1_1simple__rng.html", null ]
];