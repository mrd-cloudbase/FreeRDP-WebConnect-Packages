var files =
[
    [ "base64.hpp", null, null ],
    [ "btexception.hpp", null, null ],
    [ "common.hpp", null, null ],
    [ "logging.hpp", null, null ],
    [ "myrawsocket.hpp", null, null ],
    [ "nova_token_auth.hpp", null, null ],
    [ "NTService.hpp", null, null ],
    [ "Png.hpp", null, null ],
    [ "Primary.hpp", null, null ],
    [ "RDP.hpp", null, null ],
    [ "rdpcommon.hpp", null, null ],
    [ "sha1.hpp", null, null ],
    [ "Update.hpp", null, null ],
    [ "wscommon.hpp", null, null ],
    [ "wsendpoint.hpp", null, null ],
    [ "wsframe.hpp", null, null ],
    [ "wsgate.hpp", null, null ],
    [ "wshandler.hpp", null, null ],
    [ "wsutf8.hpp", null, null ]
];