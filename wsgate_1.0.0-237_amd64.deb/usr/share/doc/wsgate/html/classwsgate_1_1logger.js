var classwsgate_1_1logger =
[
    [ "Facility", "classwsgate_1_1logger.html#af5d67b981151d8e489ed050c704429c5", null ],
    [ "logger", "classwsgate_1_1logger.html#a58cb6b09a3c2eeab736f86afcd187af0", null ],
    [ "logger", "classwsgate_1_1logger.html#ab320e58d5bc6a8dc23fec36174cef01f", null ],
    [ "~logger", "classwsgate_1_1logger.html#a063f8205c5e2e5e81f8b5e7028693d57", null ],
    [ "disable", "classwsgate_1_1logger.html#acde14c356811981eff199e3460cdd0f2", null ],
    [ "enable", "classwsgate_1_1logger.html#a7dd409bbd123fe8a0a03fb7f0ef5ca4a", null ],
    [ "operator=", "classwsgate_1_1logger.html#a2f0658a2c8f19ec1d5aa8d73c19723f4", null ],
    [ "release", "classwsgate_1_1logger.html#afa1411ad05509c61064522ea6d0fd169", null ],
    [ "setfacility", "classwsgate_1_1logger.html#a88a825246cf4a465fd5008d74911df87", null ],
    [ "setfacilityByName", "classwsgate_1_1logger.html#aad325277f1eddfd0e25e5ea46546c8d8", null ],
    [ "setmask", "classwsgate_1_1logger.html#a99f676d28611403622f900daa6eca17a", null ],
    [ "setmaskByName", "classwsgate_1_1logger.html#adea8531ff63368c14bd24097afb57003", null ],
    [ "alert", "classwsgate_1_1logger.html#a98b8cff4af9cf5e8b954f2c655d16912", null ],
    [ "crit", "classwsgate_1_1logger.html#aefc24a2c8144cfa3de0e950665b3c264", null ],
    [ "debug", "classwsgate_1_1logger.html#a682fbe4a570b9395ee7c47e225d81de0", null ],
    [ "emerg", "classwsgate_1_1logger.html#a19a183e4bf22af61b82f01580c4e72a9", null ],
    [ "err", "classwsgate_1_1logger.html#ad731a4369a94e34667b07e0f383956a9", null ],
    [ "info", "classwsgate_1_1logger.html#ae4c8c37202a2d669c3aa89baeaa03103", null ],
    [ "notice", "classwsgate_1_1logger.html#a8736fdf80f495ef39346456ce3108464", null ],
    [ "warn", "classwsgate_1_1logger.html#ac94e1b22b5893a46a952cd1dcbcb7dea", null ]
];