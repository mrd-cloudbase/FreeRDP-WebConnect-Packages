var searchData=
[
  ['clrconv',['clrconv',['../structwsgate_1_1wsgContext.html#af500c19a73f07d21b30a5cd00db90304',1,'wsgate::wsgContext']]],
  ['crit',['crit',['../classwsgate_1_1logger.html#aefc24a2c8144cfa3de0e950665b3c264',1,'wsgate::logger']]]
];
