var searchData=
[
  ['rdp_5fptr',['rdp_ptr',['../namespacewsgate.html#a394a92f390eb41de12ae07b8dafaf32e',1,'wsgate']]]
];
