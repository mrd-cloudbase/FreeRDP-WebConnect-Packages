var searchData=
[
  ['info',['info',['../classwsgate_1_1logger.html#ae4c8c37202a2d669c3aa89baeaa03103',1,'wsgate::logger']]]
];
