var searchData=
[
  ['formvalue',['FormValue',['http://ehs.fritz-elfert.de/html/classFormValue.html#a98edbf86b7105f2f232e927f829b3675',1,'FormValue::FormValue()'],['http://ehs.fritz-elfert.de/html/classFormValue.html#a9e088979289f6442a1f21572456c62d2',1,'FormValue::FormValue(std::string &amp;irsBody, ContentDisposition &amp;ioContentDisposition)'],['http://ehs.fritz-elfert.de/html/classFormValue.html#ac5b4609fd46b07d58665a1527bb3749b',1,'FormValue::FormValue(const FormValue &amp;iroFormValue)']]],
  ['formvalues',['FormValues',['http://ehs.fritz-elfert.de/html/classHttpRequest.html#a1955dd27411888596f2864cc79c0f0be',1,'HttpRequest::FormValues()'],['http://ehs.fritz-elfert.de/html/classHttpRequest.html#a264e0a31589f066ae23ab6f16ed0855f',1,'HttpRequest::FormValues(const std::string &amp;name)']]]
];
