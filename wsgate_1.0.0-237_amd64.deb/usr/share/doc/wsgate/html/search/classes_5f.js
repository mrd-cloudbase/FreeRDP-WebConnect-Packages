var searchData=
[
  ['_5f_5fcaseless',['__caseless',['http://ehs.fritz-elfert.de/html/struct____caseless.html',1,'']]]
];
