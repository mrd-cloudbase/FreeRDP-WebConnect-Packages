var searchData=
[
  ['conn_5fmap',['conn_map',['../namespacewsgate.html#a25f05fdc2f7a0606781bc9286b8eb195',1,'wsgate']]],
  ['conn_5fptr',['conn_ptr',['../namespacewsgate.html#aae314db8088abb151bb4726f23ab1ca7',1,'wsgate']]],
  ['conn_5ftuple',['conn_tuple',['../namespacewsgate.html#a9d4436d7357bb59985e85c1420e94234',1,'wsgate']]],
  ['cursor',['cursor',['../classwsgate_1_1RDP.html#a557093f468a2b2c61e2037028aa15f1a',1,'wsgate::RDP']]]
];
