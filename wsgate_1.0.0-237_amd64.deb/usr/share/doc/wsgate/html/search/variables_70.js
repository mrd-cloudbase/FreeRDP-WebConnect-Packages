var searchData=
[
  ['perf',['perf',['../structwsgate_1_1WsRdpParams.html#ae37cbea70bb594dbf5805a062844461b',1,'wsgate::WsRdpParams']]],
  ['port',['port',['../structwsgate_1_1WsRdpParams.html#a8dd77cede716115cd407c82d08168459',1,'wsgate::WsRdpParams']]],
  ['pprimary',['pPrimary',['../structwsgate_1_1wsgContext.html#a4349978aa47427a6e401be1d607f66bd',1,'wsgate::wsgContext']]],
  ['prdp',['pRDP',['../structwsgate_1_1wsgContext.html#a03abdae92c2163a262889a1fcca49c4d',1,'wsgate::wsgContext']]],
  ['pupdate',['pUpdate',['../structwsgate_1_1wsgContext.html#a51119478548910b171be3299eea908b2',1,'wsgate::wsgContext']]]
];
