var searchData=
[
  ['length_5ferror',['length_error',['../classtracing_1_1length__error.html',1,'tracing']]],
  ['logger',['logger',['../classwsgate_1_1logger.html',1,'wsgate']]],
  ['logic_5ferror',['logic_error',['../classtracing_1_1logic__error.html',1,'tracing']]]
];
