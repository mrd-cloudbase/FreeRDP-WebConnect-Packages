var classwsgate_1_1http__exception =
[
    [ "http_exception", "classwsgate_1_1http__exception.html#adf098b9556340ae22598d73d4f1206fc", null ],
    [ "get_status_code", "classwsgate_1_1http__exception.html#a013dd07e44f12cc50dd00ebfbd6b8073", null ],
    [ "what", "classwsgate_1_1http__exception.html#ab54238cdc44d34ac806ccd12d95cd947", null ]
];